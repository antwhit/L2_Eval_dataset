import java.util.List;
import org.vramework.mvc.exceptions.MvcErrors;

/**
 * @author thomas.mahringer
 */
public class xxx {

    List<String> e;

    MvcErrors r;
}
