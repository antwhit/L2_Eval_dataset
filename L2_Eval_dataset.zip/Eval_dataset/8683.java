class WarnSyntheticNameConflict {

    static class Outer {

        WarnSyntheticNameConflict this$0 = null;
    }

    public class Inner extends Outer {
    }
}
