public class Main {

    public static void main(String[] args) {
        Changed changed = new Changed();
        changed.contract();
        System.out.println("TEST PASSED");
    }
}
