public class TextureObj {

    public String sFilename;

    public int iID;

    public TextureObj(String inFilename) {
        sFilename = inFilename;
    }

    public static void main(String args[]) {
    }
}
