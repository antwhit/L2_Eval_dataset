import org.juddi.client.*;
import org.juddi.datatype.*;
import org.juddi.datatype.business.*;
import org.juddi.datatype.request.*;
import org.juddi.datatype.response.*;
import org.juddi.error.*;
import org.juddi.registry.*;
import java.util.Vector;
import java.io.File;

/**
 * @author Steve Viens (sviens@users.sourceforge.net)
 */
public class GetAssertionStatusReportSample {

    public static void main(String[] args) {
        RegistryProxy proxy = new RegistryProxy();
        try {
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
