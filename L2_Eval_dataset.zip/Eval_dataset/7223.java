public class e2position {

    int col;

    int row;

    int rotation;

    public e2position(int in_col, int in_row, int in_rotation) {
        row = in_row;
        col = in_col;
        rotation = in_rotation;
    }
}
