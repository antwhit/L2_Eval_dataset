public class T1627s2 {

    public static void main(String[] args) {
        if (true) {
            final int i = 1;
        }
        final int i;
        i = 2;
    }
}
