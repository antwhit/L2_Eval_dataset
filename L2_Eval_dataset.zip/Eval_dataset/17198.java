public abstract class test396j {

    public test396j() {
        abstractMethod();
    }

    public abstract void abstractMethod();
}
