public class T1617sduf5 {

    public static void main(String[] args) {
        final int x;
        int i = x = 0;
        i = x = 1;
    }
}
