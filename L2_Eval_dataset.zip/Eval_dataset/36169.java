public class test206j1 implements test206j0 {

    public int getInt() {
        return 3;
    }

    public int getInt2() {
        return 4;
    }
}
