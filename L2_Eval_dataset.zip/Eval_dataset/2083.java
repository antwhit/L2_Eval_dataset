public class wflwmain {

    /**
	 * @param args
	 */
    public static void main(String[] args) {
        WFLW wflw = new WFLW();
        @SuppressWarnings("unused") MainWindow mainWindow = new MainWindow(wflw);
    }
}
