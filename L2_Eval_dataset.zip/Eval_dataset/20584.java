class Test {

    static {
        System.err.println(1D);
        System.err.println(-1d);
        System.err.println(-1F);
        System.err.println(1f);
        System.err.println(10.7e2);
        System.err.println(10.7e-2);
        System.err.println(-10.7e2);
        System.err.println(-10.7e-2);
        System.err.println(1L);
        System.err.println(1l);
        System.err.println(0x1);
    }
}
