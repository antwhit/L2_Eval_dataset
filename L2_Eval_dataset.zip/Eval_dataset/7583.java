import java.awt.*;

public class ftest {

    public static void main(String[] s) {
        System.out.println("-- default toolkit ---");
        System.out.println(Toolkit.getDefaultToolkit().getClass().getName());
    }
}
