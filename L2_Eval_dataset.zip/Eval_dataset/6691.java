public class SimplifyBooleanReturns2 {

    public boolean foo() {
        if (true) return true; else return false;
    }
}
