public class EmptyCatchBlock2 {

    public EmptyCatchBlock2() {
        try {
        } catch (RuntimeException e) {
            e.getMessage();
        }
    }
}
