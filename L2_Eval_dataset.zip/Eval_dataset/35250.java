public class OutputService {

    public int write(int x) {
        System.out.println("Output is " + x);
        return x;
    }
}
