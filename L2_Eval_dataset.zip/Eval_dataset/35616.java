public class LongVariableLocal {

    public static void main(String args[]) {
        int abcdefghijklmnopqrstuvwxyz = -1;
    }
}
