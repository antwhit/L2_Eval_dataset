import com.webobjects.appserver.WOComponent;
import com.webobjects.appserver.WOContext;

public class Layout extends WOComponent {

    public Layout(WOContext arg0) {
        super(arg0);
    }
}
