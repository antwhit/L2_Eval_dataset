class ConditionalArgTypes_2 {

    public static void main(String[] args) {
        boolean b = true;
        System.out.println(b ? 0 : false);
    }
}
